@extends('layouts.public')

@section('content')
  <main class="main" role="main">
    <section class="main__article">
      @postItemSingleton( $post->toArray() )
      @endpostItemSingleton
      <hr>
      <section class="main__similarArticles similarArticles">
          <h1 class="similarArticles__heading"> Similar Articles </h1>
          <ul class="articleList">
      		 	<li class="articleList__item">
              @foreach( $similar_posts as $_post )
                  @include('components.posts.postItem_2', $_post->toArray())
              @endforeach
            </li>
          </ul>
      </section>
      <div class="px-md-5 px-3 py-3">
          @homepageSubscribeForm
          @endhomepageSubscribeForm
      </div>
    </section>
  </main>
@endsection
