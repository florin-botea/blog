<section class="archive mt-4">
  <h2 class="archive__heading"> Archive </h2>
  <hr>
  <ul class="archive__list mt-4">
    @foreach ($archives as $archive)
    <li class="archive__item">
      <a class="archive__item" href="{{ route('archives', ['month'=>$archive->month, 'year'=>$archive->year]) }}">
        @lang('calendar.month.'.$archive->month) {{ $archive->year. ' ('. $archive->count .')' }}
      </a>
    </li>
    @endforeach
  </ul>
</section>
