<nav class="navbar navbar-dark bg-dark px-5 py-1">
	<ul class="ml-auto m-0" style="list-style: none;">
		<li class="nav-item dropdown ml-auto">
			<a class="nav-link py-0 text-white" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Postari
			</a>
			<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
				<a class="dropdown-item" href="/posts/create"><i class="fas fa-plus"></i> New post </a>
				<a class="dropdown-item" href="#">Link</a>
				<a class="dropdown-item" href="#">Link</a>
			</div>
		</li>
	</ul>
</nav>