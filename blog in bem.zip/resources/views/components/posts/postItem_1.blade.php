@php
    $date = Carbon\Carbon::parse($created_at);
    $now = Carbon\Carbon::now();
@endphp

<article class="article article--sample article--sample-flex">
  <div class="article__imageSection">
    <figure class="article__frame">
      <a href="{{ route('posts.show', ['post' => $slug]) }}"><img class="article__image" src="{{ asset('storage/'.( $photo??'#' )) }}"></a>
    </figure>
  </div>
  <article class="article__content">
    <h2 class="article__title">
      <a class="article__title" href="{{ route('posts.show', ['post' => $slug]) }}">{{ $title ?? 'No title' }}</a>
    </h2>
    @if ( $now->diffInDays($date) < 2 )
    <span class="badge badge-outlined-success py-0 leading-none px-1"> Fresh </span>
    @elseif( $now->diffInDays($date) < 5 )
    <span class="badge badge-outlined-warning py-0 leading-none px-1"> Nou </span>
    @endif
    <div class="article__meta meta">
      <aside class="article__author">admin</aside>
      <time class="article__time" datetime="{{ $created_at }}">-@datetime(['datetime' => $created_at])</time>
    </div>
    <div class="article__text">
      <a href="{{ route('posts.show', ['post' => $slug]) }}">{{ $sample ?? 'no article sample' }}...</a>
    </div>
  </article>
</article>
