<article class="article article--sample article--sample-card">
  <div class="article__imageSection">
    <figure class="article__frame">
      <a href="{{ route('posts.show', ['post' => $slug]) }}"><img class="article__image" src="{{ asset('storage/'.( $photo??'#' )) }}"></a>
    </figure>
  </div>
  <article class="article__content">
    <h2 class="article__title">
      <a class="article__title" href="{{ route('posts.show', ['post' => $slug]) }}">{{ $title ?? 'No title' }}</a>
    </h2>
    <div class="article__text">
      <a href="{{ route('posts.show', ['post' => $slug]) }}">{{ $sample ?? 'no article sample' }}...</a>
    </div>
  </article>
</article>
