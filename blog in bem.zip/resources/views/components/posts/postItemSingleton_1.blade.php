<article class="article px-2 md:px-8">
  <section class="article__shareSection">
    @include('components.share.shareRow_1', array_flip(['facebook', 'twitter', 'email', 'whatzapp']))
  </section>
  <header class="article__header">
    <h1 class="article__title">{{ $title ?? 'no title' }}</h1>
    <section class="article__meta">
      <aside class="article__author">admin</aside>
      <time class="article__time" datetime="{{ $created_at }}">-@datetime(['datetime' => $created_at])</time>
    </section>
  </header>
  <div class="article__imageSection">
    <figure class="article__frame">
      <img class="article__image" src="{{ asset('storage/'.$photo) }}">
    </figure>
  </div>
  <blockquote class="article__exhortation">{{ $sample }}</blockquote>
  <div class="article__content">{!! $content !!}</div>
  <footer class="article__footer">
    <aside class="text-right">
      reads: 50
    </aside>
    <section class="article__tags tags">
      <h2 class="tags__heading">Tags:</h2>
      @foreach ($tags as $tag)
      <span class="tag">{{ $tag['name'] }}</span>
      @endforeach
    </section>
  </footer>
  <hr class="my-4">
  <section class="article__comments">
    <article class="commentsSection">
      <h2 class="commentsSection__heading"> Comments: </h2>
      <div class="fb-comments" data-href="http://localhost:8080/posts/maecenas-vida-mi-in-nisi-faucibus-dignissim" width="100%" data-width="100%" data-numposts="5"></div>
    </article>
  </section>
</article>
