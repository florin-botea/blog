<nav class="navbar navbar-expand-lg navbar-light bg-light w-100">
	<a href="/"><img src="/logo.jpeg" style="height:100px; width:auto;"></a>
	
	<button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse mr-5" id="navbarSupportedContent">
		<ul class="navbar-nav ml-auto">
			<li class="nav-item mx-3 active">
				<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
			</li>
			<li class="nav-item mx-3">
				<a class="nav-link" href="#">Link</a>
			</li>
			<li class="nav-item mx-3">
				<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
			</li>
		</ul>
	</div>
</nav>