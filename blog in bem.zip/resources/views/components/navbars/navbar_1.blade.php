<header>
	<nav class="navbar">
		<div class="navbar__logo">
				<img src="/logo.jpeg">
		</div>
		<a class="navbar__sandwich js-toggle" data-target="#nav--collapse">
			<i class="fas fa-bars transpa-click"></i>
		</a>
		<ul class="navbar__nav nav nav--collapse" id="nav--collapse" aria-expanded="false">
			<li class="nav__item">nav item 1</li>
			<li class="nav__item uppercase px-2">nav item 2</li>
			<li class="nav__item uppercase px-2">nav ite 2</li>
			<li class="nav__item uppercase px-2">nav item 2</li>
			<li class="nav__item uppercase px-2">nav item 2</li>
			<li class="nav__item uppercase px-2">nav item 2</li>
		</ul>
	</nav>
</header>
