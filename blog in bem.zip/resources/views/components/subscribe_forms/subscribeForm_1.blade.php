
  <form class="my-2 px-5 simple-subscription-form">
    <h4>Subscribe</h4>
    <p>Receive updates and latest news direct from our team. Simply enter your email below :</p>
    <div class="input-group">
      <span class="input-group-label">
        <i class="fa fa-envelope"></i>
      </span>
      <input class="input-group-field" type="email" placeholder="Email" required>
      <button class="button">Sign up now</button>
    </div>
  </form>