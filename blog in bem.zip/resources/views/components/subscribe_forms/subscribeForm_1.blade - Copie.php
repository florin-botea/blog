<form class="my-2 px-5 text-center">
    <h4> Aboneaza-te la newsletter-ul nostru pentru a primi noutati pe mail </h4>
    <input class="form-control" type="email" placeholder="example@example.ro" aria-label="Subscribe">
    <button class="btn btn-outline-info btn-rounded btn-block z-depth-0 my-2 waves-effect" type="submit">
        Aboneaza-te
    </button>
</form>