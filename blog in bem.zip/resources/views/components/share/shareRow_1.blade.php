<div class="share share--row">
  <a class="share__item--main self-center">
    <i class="fas fa-share-alt"></i>
  </a>
  @isset($facebook)
  <a class="share__item">
    <img class="share__icon share__icon--facebook">
  </a>
  <a class="share__item">
    <img class="share__icon share__icon--facebookMessenger">
  </a>
  @endisset
  @isset($twitter)
  <a class="share__item">
    <img class="share__icon share__icon--twitter">
  </a>
  @endisset
  @isset($tumbir)

  @endisset
  @isset($email)

  @endisset
  @isset($pinterest)

  @endisset
  @isset($linkedin)

  @endisset
  @isset($whatzapp)
  <a class="share__item">
    <img class="share__icon share__icon--whatzapp">
  </a>
  @endisset
</div>
