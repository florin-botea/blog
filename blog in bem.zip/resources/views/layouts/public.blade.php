<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="{{ isset($post) ? $post->description : 'website description' }}"/>
    <link rel="icon" href="/logo.jpeg">
    <link rel="stylesheet" href='/css/app.css'>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ isset($post) ? ($post->title .' - '. request()->getHost()) : 'website title' }}</title>
    <style>
        .right-0 {
            right: 0px;
        }

.simple-subscription-form {
  background: #0c3e5f;
  color: #fefefe;
  padding: 2rem;
  border-radius: 0;
}

.simple-subscription-form .button {
  margin-bottom: 0;
  border-radius: 0 0 0 0;
}
    </style>
</head>

<body>
    <div class="flex flex-col min-vh-100">
        adminDashboard
    		endadminDashboard
        @include('components.navbars.navbar_1')
        <div class="content">
            <div class="content__main">
                @yield('content')
            </div>

            <div class="content__extras">
                @include('components.lists.popular_posts.popularPostsList_1', ['popular' => $popular->all()])
                @include('components.lists.last_posts.lastPostsList', ['posts' => $posts])

                <div class="extras">
                    <form class="searchForm input input--row">
                        <input class="searchForm__input input__control" type="search" placeholder="Search" aria-label="Search">
                        <button class="searchForm__submit" type="submit">Search</button>
                    </form>
                    <hr>
                    @postsArchiveList(['archives' => $archives ?? []])
                    @endpostsArchiveList
                </div>
            </div>
        </div>

        @footer
        @endfooter

    </div>

    <div class="position-fixed btn" style="bottom:50px; right:50px; font-size: 3rem;">
        <i class="fas fa-angle-up"></i>
    </div>
    <script src="/js/public.js"></script>
    <script>
      $('.js-toggle').click(function(e){
        let el = $(e.target.dataset.target);
        if (!el) return;
        let expanded = el.attr('aria-expanded') === 'true';
        !expanded ? el.addClass('expanded') : el.removeClass('expanded');
        el.attr('aria-expanded', !expanded)
      })
    </script>

    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/ro_RO/sdk.js#xfbml=1&version=v5.0"></script>
</body>
</html>
