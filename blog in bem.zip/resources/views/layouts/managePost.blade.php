<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content=""/>
    <link rel="stylesheet" href='/css/app.css'>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Blog </title>
    <style>
        .right-0 {
            right: 0px;
        }
    </style>
</head>

<body>
    <div class="d-flex flex-column min-vh-100">
        @adminDashboard
		@endadminDashboard
		@navbar
        @endnavbar
        
        <div class="container-fluid p-0 flex-fill pb-5">
            <div class="row mx-auto">
                <div class="col-md-8 p-0">
                    <div class="px-md-5 px-3 py-3 text-justify">
                        <hr>
						@yield('form')
						
                    </div>
                </div>
                
                <div class="col-md-4 p-0">
                    <div class="px-5 py-3">
                        @popularPostsList(['popular' => $popular->all()])
                        @endpopularPostsList
                    </div>
                
                    <div class="px-5 py-3">
                        @lastPostsList(['posts' => $recent_posts])
                        @endlastPostsList
                    </div>
                
                    <div class="p-5">
                        <form class="d-flex my-2 align-items-center">
                            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                        </form>
                        <p class="underlined w-100"></p>
                        @postsArchiveList(['archives' => $archives ?? []])
                        @endpostsArchiveList
                    </div>
                
                
                </div>
            </div>
        </div>
        
        @footer
        @endfooter
        
    </div>
    
    <div class="position-fixed btn" style="bottom:50px; right:50px; font-size: 3rem;">
        <i class="fas fa-angle-up"></i>
    </div>
	<script src="/js/admin.js"></script>
</body>
</html>
