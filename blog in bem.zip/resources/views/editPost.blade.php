@extends('layouts.managePost')

@php
    $tags = array_map( function($tag){
        return $tag['name'];
    }, $post['tags']->toArray());
    $tags = implode(', ',$tags);
    $post['tags'] = $tags;
@endphp

@section('form')
    @component('partials.forms.form', ['action'=> route('posts.update', ['post' => $post->id]), 'attrs'=>['enctype'=>'multipart/form-data'] ])
        @method('put')
        @foreach ( $form_fields as $field )
            @formGroup(array_merge($field, [
                'value' => $post[ $field['name'] ]
            ]))
            @endformGroup
        @endforeach
        <div class="mt-2 d-flex justify-content-end">
            @component('partials.forms.formSubmit', ['class'=>'btn-primary'])
                Submit
            @endcomponent
        </div>
    @endcomponent
@endsection