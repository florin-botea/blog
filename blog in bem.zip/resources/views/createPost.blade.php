@extends('layouts.managePost')

@section('form')
    @component('partials.forms.form', ['action'=> route('posts.store'), 'attrs'=>['enctype'=>'multipart/form-data'] ])
        @foreach ( $form_fields as $field )
            @formGroup(array_merge($field, [
                'value' => old($field['name'])
            ]))
            @endformGroup
        @endforeach
        <div class="mt-2 d-flex justify-content-end">
            @component('partials.forms.formSubmit', ['class'=>'btn-primary'])
                Submit
            @endcomponent
        </div>
    @endcomponent
@endsection