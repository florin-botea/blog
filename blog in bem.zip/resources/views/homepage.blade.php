@extends('layouts.public')

@section('content')
  <main class="main" role="main">
    @if ( request()->month && request()->year )
    <div class="col px-5">
        <h1> Arhiva @lang('calendar.month.'.request()->month) {{ request()->year }} </h1>
    </div>
    @endif
    @if ($posts->firstItem())
    <section class="main__article lastArticle">
      <h1 class="hidden">{{ $posts->items()[0]->description }}</h1>
      @include('components.posts.postItem_1', $posts->items()[0]->toArray() )
    </section>
    @endif
    <hr>
    <div class="main__articlesList">
      <ul class="articlesList">
        <li class="articleList__item">
        @foreach ( $posts->items() as $_post )
          @if ( $loop->first ) @continue @endif
          @include('components.posts.postItem_1', $_post->toArray() )
        @endforeach
        </li>
      </ul>
      <hr>
      @homepagePagination($posts->toArray())
      @endhomepagePagination
      <hr>
      <div class="px-0 px-md-5">
        @homepageSubscribeForm
        @endhomepageSubscribeForm
      </div>
    </div>
  </main>
@endsection
