<?php

return [
    'day' => [
        'Sun' => 'Sunday',
        'Thu' => 'Thusday',
        'Wed' => 'Wednesday',
    ],
    
    'month' => [
        'Nov' => 'November',
        'Oct' => 'October',
        '11' => 'November',
        '10' => 'October',
    ]
];