window.axios = require('axios');
window.$ = window.jquery = require('jquery');
window.popper = require('popper.js');
//require('bootstrap');

window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

$('.prevent-multi-submit').submit(function(e){
	$(e.target).find('.btn-with-spinner').prop('disabled', true);
});
